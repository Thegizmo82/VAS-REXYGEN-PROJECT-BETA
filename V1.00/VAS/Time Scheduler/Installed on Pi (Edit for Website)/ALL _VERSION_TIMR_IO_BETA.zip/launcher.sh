#!/bin/sh
# launcher.sh
# navigate to home directory, then to this directory, then execute python script, then back home

cd /
cd home/pi/VAS
sudo python time_io_ver_b2.0.py
cd /


